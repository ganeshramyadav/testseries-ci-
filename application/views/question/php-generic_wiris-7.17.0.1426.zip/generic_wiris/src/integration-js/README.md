MathType Web Integration JavaScript SDK
==========
## Master Build status
![Build status](https://api.travis-ci.org/wiris/mathtype-integration-js-dev.svg?branch=master)

## Install instructions

Clone the repository:

```bash
$ git clone https://github.com/wiris/mathtype-integration-js-dev
```

Install dependencies:

```bash
$ npm install
```

Compile:

```bash
$ npm run build-dev
```
